package com.example.recyclerviewapp1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerviewapp1.databinding.ItemViewBinding

class HomeRecyclerViewAdapter(val dataList : MutableList<Email>) : RecyclerView.Adapter<HomeRecyclerViewAdapter.HomeRecyclerViewHolder>() {

    inner class HomeRecyclerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val binding = ItemViewBinding.bind(itemView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeRecyclerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view, parent, false)
        return HomeRecyclerViewHolder(view)
    }

    override fun onBindViewHolder(holder: HomeRecyclerViewHolder, position: Int) {
        val item = dataList[position]
        holder.binding.apply {
            emailAuthorTv.text = item.author
            emailSubjectTv.text = item.subject
            contentTv.text = item.content
//            imageView.setImageResource(item.image!!)
        }
    }

    override fun getItemCount() = dataList.size
}