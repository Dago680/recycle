package com.example.recyclerviewapp1

data class Email(
    val author: String? = null,
    val subject: String? = null,
    val content: String? = null,
    val image: Int? = null
)
