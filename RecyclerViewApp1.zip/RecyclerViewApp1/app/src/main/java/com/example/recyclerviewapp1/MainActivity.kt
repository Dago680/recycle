package com.example.recyclerviewapp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recyclerviewapp1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {


    private lateinit var binding : ActivityMainBinding

    private lateinit var homeRVAdapter : HomeRecyclerViewAdapter



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.apply {
            homeRVAdapter = HomeRecyclerViewAdapter(getData())
            homeRv.adapter = homeRVAdapter
            homeRv.layoutManager = LinearLayoutManager(this@MainActivity)
        }

    }

    private fun getData(): MutableList<Email> {
        var dataList = ArrayList<Email>()
        dataList.add(Email("author 1", "subject 1", "content 1 content 1 content 1 content 1"))
        dataList.add(Email("author 2", "subject 2", "content 2 content 1 content 1 content 1"))
        dataList.add(Email("author 3", "subject 3", "content 3 content 1 content 1 content 1"))
        dataList.add(Email("author 4", "subject 4", "content 4 content 1 content 1 content 1"))
        dataList.add(Email("author 5", "subject 5", "content 5 content 1 content 1 content 1"))
        dataList.add(Email("author 6", "subject 6", "content 6 content 1 content 1 content 1"))
        dataList.add(Email("author 7", "subject 7", "content 7 content 1 content 1 content 1"))
        dataList.add(Email("author 8", "subject 8", "content 8 content 1 content 1 content 1"))

        return dataList


    }
}